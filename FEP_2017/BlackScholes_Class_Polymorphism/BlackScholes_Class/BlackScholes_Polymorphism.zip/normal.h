
#ifndef _NORMAL_H_
#define _NORMAL_H_

double normpdf(double x, double mu=0, double sigma=1);
double normcdf(double x, double mu=0, double sigma=1);

#endif